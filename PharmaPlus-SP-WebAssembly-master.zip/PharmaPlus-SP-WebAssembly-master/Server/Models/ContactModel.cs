﻿namespace PharmaPlus.Server.Models
{
    public class ContactModel
    {
    }
}
