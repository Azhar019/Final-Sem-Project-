﻿using Microsoft.AspNetCore.Identity;

namespace PharmaPlus.Server.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}